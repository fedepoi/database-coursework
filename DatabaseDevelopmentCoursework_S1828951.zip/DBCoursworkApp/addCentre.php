<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "CW_FV";

  $cC = $_POST["cCode"];
  $cN = $_POST["cName"];
  $cL = $_POST["cLoc"];
  
  // $s1=$_POST["shop1"];
  // $s2=$_POST["shop2"];
  // $s3=$_POST["shop3"];
  
  // $cS1=$_POST["categoryS1"];
  // $cS2=$_POST["categoryS2"];
  // $cS3=$_POST["categoryS3"];
  
  // $r1=$_POST["rating1"];
  // $r2=$_POST["rating2"];
  // $r3=$_POST["rating3"];

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
  }

  $sql = "Insert Into shoppingcentre_FV (CentreCode, CentreName,CentreLocation) Values('" .  $cC . "' , '" . $cN . "', '" . $cL ." ')";
  $result = $conn->query($sql);
  
  // $sql2 ="Insert into shop_FV (ShopName) values('". $s1 . "'),('". $s2 . "'),('".$s3."')";
  // $result = $conn->query($sql2);
  
  // $sql3="Insert Into ShoppingCentreShop_FV ( CentreCode , ShopNo , Category , CustomerRating) values( '".$cC."','".$s1."','".$cS1."','".$r1."'),('".$cC."','".$s2."','".$cS2."','".$r2."'),('".$cC."','".$s3."','".$cS3."','".$r3."')";
  // $result = $conn->query($sql3);
  
  
  header('Location: centrePage.php');
?>