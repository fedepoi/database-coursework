<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "CW_FV";

  $cC = $_POST["cCode"];
  $cN = $_POST["cName"];
  $cL = $_POST["cLoc"];
  
  $s1=$_POST["shop1"];
  

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
  }

  $sql ="Insert into shop_FV (ShopName) values('". $s1 . "')";
  $result = $conn->query($sql);
  
  
  header('Location: index.php');
?>