<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "CW_FV";

  $cC = $_POST["cCode"];
  $shop=$_POST["shopN"];
  $cat=$_POST["cat"];
  $rat=$_POST["rat"];

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
  }
  
  $sql="Insert Into ShoppingCentreShop_FV ( CentreCode , ShopNo , Category , CustomerRating) values( '".$cC."','".$shop."','".$cat."','".$rat."')";
  $result = $conn->query($sql);
  
  
  header('Location: centreWithShopPage.php');
?>