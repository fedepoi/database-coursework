<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="cssDBCW.css">
</head>
<body>
<div class="grid-container">
<div class="header">
<h2>Shopping centre app</h2>
<h4><a href ="index.php">home</a></h4>
</div>
<div class="left">
<ul>
<li> <a href="index.php">Home</a></li>
<li><a href="">centre</a></li>
<li><a href="centreWithShopPage.php">centre and shops</a></li>
</ul>
</div>

<div class="middle">

<div id="shopDiv">
		<?php include 'getCentre.php';?>
		</div>
</div>






<div class="right"></div>
  <div class="footer">
    <p>Federico Vivaldo database Coursework 2020</p>
  </div>




</div>
</body>

</html>