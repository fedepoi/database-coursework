<?php
  $servername = "localhost:3306";
  $username = "root";
  $password = "";
  $dbname = "CW_FV";

  
  $conn = new mysqli($servername, $username, $password, $dbname);


  if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
  }
  $sql = "SELECT
shoppingcentre_fv.CentreName,
shoppingcentre_fv.CentreLocation,
shoppingcentreshop_fv.ShopNo,
shop_fv.ShopName
from shoppingcentre_fv
left JOIN shoppingcentreshop_fv on shoppingcentreshop_fv.CentreCode=shoppingcentre_fv.CentreCode
left join shop_fv on shop_fv.ShopNo=shoppingcentreshop_fv.ShopNo
";
  $result = $conn->query($sql);
  $html="";
  if ($result->num_rows > 0) {

	  while($row = $result->fetch_assoc()) {
		  $html .= '<div style="padding:10px;background-color:#dbefdc;margin:10px;">' . $row["CentreName"] . ' : ' . $row["CentreLocation"] . ' : ' .$row["ShopNo"].':'.$row["ShopName"].'</div>' ;
		  
	  }
  } else {
	  $html .= "0 results";
  }
  echo $html;
?>