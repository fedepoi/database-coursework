<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "CW_FV";

  
  $conn = new mysqli($servername, $username, $password, $dbname);


  if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
  }
  $sql = "select shopNo,shopName from shop_fv";
  $result = $conn->query($sql);
  $html="";
  if ($result->num_rows > 0) {

	  while($row = $result->fetch_assoc()) {
		  $html .= '<div style="padding:10px;background-color:#dbefdc;margin:10px;">' . $row["shopNo"] . ' : ' . $row["shopName"] . '</div>' ;
		  
	  }
  } else {
	  $html .= "0 results";
  }
  echo $html;
?>