<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="cssDBCW.css">
</style>

<script>
    function add() {
		// document.getElementById("addFormDiv").style.display = 'block';
		var x = document.getElementById("addFormDiv");
        if (x.style.display === "none") {
        x.style.display = "block";
        } else {
        x.style.display = "none";
        }		
		
	}
    function addShopToCentre() {
		// document.getElementById("addShopToCentreDiv").style.display = 'block';
		//document.getElementById("getCentreDiv").style.display = 'block';
		//document.getElementById("getShopsDiv").style.display = 'block';
     var x = document.getElementById("addShopToCentreDiv");
     if (x.style.display === "none") {
     x.style.display = "block";
     } else {
     x.style.display = "none";
     }	
  
     var y = document.getElementById("getCentreDiv");
     if (y.style.display === "none") {
     y.style.display = "block";
     } else {
     y.style.display = "none";
     }	
  
     var z = document.getElementById("getShopsDiv");
     if (z.style.display === "none") {
     z.style.display = "block";
     } else {
     z.style.display = "none";
     }		
		
	}
	
    function addShop() {
		//document.getElementById("addShopDiv").style.display = 'block';
		
		 var x = document.getElementById("addShopDiv");
         if (x.style.display === "none") {
         x.style.display = "block";
         } else {
         x.style.display = "none";
          }	
	}
	
</script>
</head>

<body>
<div class="grid-container">
<div class="header">
<h2>Shopping centre app</h2>
</div>
<div class="left">
<ul>
<li> <a href="index.php">Home</a></li>
<li><a href="centrePage.php">centre</a></li>
<li><a href="centreWithShopPage.php">centre and shops</a></li>
</ul>	
</div>

<div class="middle">

<button id="addCentre" class="button" onclick="add()">add ShoppingCentre</button> <br>

<div id="addFormDiv" style="display: none;">			
			<form id="addForm" method="post" action="addCentre.php">
			 Centre code:<input type="text" name="cCode" /><br>
				Centre name: <input type="text" name="cName" /><br>
				Centre location:<input type="text" name="cLoc" /><br>
				<input type="submit" value="Add" />	
			</form>
		
</div>


<button id="addShop" class="button" onclick="addShop()">add Shop</button><br>
<div id="addShopDiv" style="display:none;">
<form id="addNewShopForm" method="post" action="addShop.php">
Shop Name : <input type="text" name="shop1"/><br>
<input type="submit" value="Add" />	
</form>
</div>

<button id="addShopToCentre" class="button" onclick="addShopToCentre()">add Shop To an existing centre</button>

<div id="addShopToCentreDiv" style="display:none;">
<form id="addShopForm" method="post" action="addShopToCentre.php">
Centre code: <input type="text" name="cCode" /><br>
Shop No : <input type="number"  name="shopN" min="1"><br>
Category <select  name="cat">
                <option value="ENTERTAINMENT">ENTERTAINMENT</option>
                <option value="FOOD">FOOD</option>
                <option value="FASHION">FASHION</option>
                </select><br>
Customer rating : <input type="number"  name="rat" min="1" max="5"><br>
<input type="submit" value="Add" />	
</form> 
</div>
</div>
<div class="right">     

<div id="getCentreDiv" style="display:none;" > 
Centres:
<?php include 'getCentreCode_CentreName.php';?>
		</div> 
<div id="getShopsDiv" style="display:none;" > 
Shops:
<?php include 'getShops.php';?>
		</div>
</div>
   
</div>
  <div class="footer">
    <p>Federico Vivaldo database Coursework 2020</p>
  </div>
</div>
</body>

</html>