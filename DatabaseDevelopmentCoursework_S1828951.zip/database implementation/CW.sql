drop database if exists CW_FV;
CREATE DATABASE IF NOT EXISTS CW_FV DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE CW_FV;

drop table if exists ShoppingCentre_FV;
create table ShoppingCentre_FV (
CentreCode VARCHAR(20) not null,
CentreName VARCHAR(20) not null,
CentreLocation VARCHAR(50) not null,
CONSTRAINT UK_ShoppingCentre UNIQUE (CentreCode,CentreName),
constraint ShppingCentre_PK primary key (CentreCode));

drop table if exists Shop_FV;
create table Shop_FV (
ShopNo int(3) not null auto_increment,
ShopName varchar(20) not null,
CONSTRAINT UK_Shop UNIQUE (ShopNo,ShopName),
constraint Shop_PK primary key (ShopNo));

drop table if exists ShoppingCentreShop_FV;
create table ShoppingCentreShop_FV(
CentreCode varchar(20) not null,
ShopNo int(3) not null,
Category ENUM ('FASHION','ENTERTAINMENT','FOOD') not null,
CustomerRating int(3) not null,
CHECK (CustomerRating >= 1 AND CustomerRating <= 5),
constraint ShopCentrShop_pk primary key (CentreCode, ShopNo));


alter table ShoppingCentreShop_FV add
foreign key (CentreCode) references ShoppingCentre_FV (CentreCode);

alter table ShoppingCentreShop_FV add
foreign key (ShopNo) references Shop_FV(ShopNo);

DELIMITER $
create trigger centreCodeS before insert on ShoppingCentre_FV
FOR EACH ROW BEGIN
 if new.CentreCode not LIKE 'S%' then
signal sqlstate '45000' set message_text = 'Centre code value should start with capital S ';
 end if;
 end $
DELIMITER ;

DELIMITER $
create trigger centreCodeSup before update on ShoppingCentre_FV
FOR EACH ROW BEGIN
 if new.CentreCode not LIKE 'S%' then
signal sqlstate '45000' set message_text = 'Centre code value should start with capital S ';
 end if;
 end $
DELIMITER ;

