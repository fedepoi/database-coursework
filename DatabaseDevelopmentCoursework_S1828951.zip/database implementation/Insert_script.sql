insert into ShoppingCentre_FV (`CentreCode`,`CentreName`,`CentreLocation`) values ('S1234','the Ark','192 Argyle Street');
insert into ShoppingCentre_FV (`CentreCode`,`CentreName`,`CentreLocation`) values ('S3456','Big Centre','12 big Street');
insert into ShoppingCentre_FV (`CentreCode`,`CentreName`,`CentreLocation`) values ('S1455','Pyramid','45 Egypt Street');
insert into ShoppingCentre_FV (`CentreCode`,`CentreName`,`CentreLocation`) values ('S9876','Fairyland','56 Boston Street');
insert into ShoppingCentre_FV (`CentreCode`,`CentreName`,`CentreLocation`) values ('S3356','Building 4','13 Combee Street');

insert into Shop_FV (`shopName`) values('carol bakery');
insert into Shop_FV (`shopName`) values('tools and more');
insert into Shop_FV (`shopName`) values('Game Store');
insert into Shop_FV (`shopName`) values('sport shop');
insert into Shop_FV (`shopName`) values('Fred pet shop');
insert into Shop_FV (`shopName`) values('Make up is fun');
insert into Shop_FV (`shopName`) values('Green superstore');
insert into Shop_FV (`shopName`) values('Fish & co.');
insert into Shop_FV (`shopName`) values('tech shop');
insert into Shop_FV (`shopName`) values('Guitar & Drumms');

insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S1234','1','FOOD','4');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S1234','3','ENTERTAINMENT','3');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S1234','7','FOOD','5');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S1234','2','ENTERTAINMENT','2');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S1234','4','FASHION','4');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S9876','5','ENTERTAINMENT','4');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S9876','6','FASHION','2');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S9876','8','FOOD','5');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S9876','9','ENTERTAINMENT','1');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S9876','10','ENTERTAINMENT','5');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S9876','3','ENTERTAINMENT','3');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S9876','1','FOOD','4');

insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S3456','3','ENTERTAINMENT','3');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S3456','1','FOOD','4');
insert into ShoppingCentreShop_FV (`CentreCode`,`ShopNo`,`Category`,`CustomerRating`) values ('S1455','1','FOOD','4');



