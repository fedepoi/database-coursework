SELECT concat(shoppingcentre_fv.CentreName,'-',shoppingcentre_fv.CentreLocation) "Centre" 
from shoppingcentre_fv
ORDER by CentreName;