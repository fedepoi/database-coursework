SELECT shop_fv.shopNo , shop_fv.ShopName from shoppingcentreshop_fv
inner JOIN shop_fv on shop_fv.ShopNo=shoppingcentreshop_fv.ShopNo
where shoppingcentreshop_fv.Category= 'FASHION';


