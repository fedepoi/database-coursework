SELECT * from shoppingcentre_fv
left JOIN shoppingcentreshop_fv on shoppingcentreshop_fv.CentreCode=shoppingcentre_fv.CentreCode
left join shop_fv on shop_fv.ShopNo=shoppingcentreshop_fv.ShopNo
order by shoppingcentre_fv.CentreCode