SELECT
shoppingcentre_fv.CentreCode,
shoppingcentre_fv.CentreName,
shoppingcentre_fv.CentreLocation,
shoppingcentreshop_fv.ShopNo,
shoppingcentreshop_fv.Category,
shoppingcentreshop_fv.CustomerRating,
shop_fv.ShopName
from shoppingcentre_fv
left JOIN shoppingcentreshop_fv on shoppingcentreshop_fv.CentreCode=shoppingcentre_fv.CentreCode
left join shop_fv on shop_fv.ShopNo=shoppingcentreshop_fv.ShopNo
order by shoppingcentre_fv.CentreCode



